import 'package:flutter/material.dart';

void main() {
  runApp(const KarangTarunaApp());
}

class KarangTarunaApp extends StatelessWidget {
  const KarangTarunaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Karang Taruna Online',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B4D)),
        scaffoldBackgroundColor: const Color(0xFFF7F8F6),
      ),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.groups_rounded, size: 90, color: Color(0xFF176B4D)),
            SizedBox(height: 20),
            Text(
              'KARANG TARUNA',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
            ),
            Text(
              'ONLINE',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: 4),
            ),
            SizedBox(height: 12),
            Text('Satukan Pemuda, Gerakkan Desa.'),
          ],
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void login() {
    if (emailController.text.trim().isEmpty || passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Email dan password wajib diisi.')),
      );
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MainShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 45),
              const Icon(Icons.groups_rounded, size: 55, color: Color(0xFF176B4D)),
              const SizedBox(height: 24),
              const Text(
                'Selamat datang',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              const Text('Masuk ke Karang Taruna Online.'),
              const SizedBox(height: 32),
              TextField(
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email',
                  prefixIcon: const Icon(Icons.email_outlined),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  prefixIcon: const Icon(Icons.lock_outline),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: FilledButton(
                  onPressed: login,
                  child: const Text('MASUK'),
                ),
              ),
              const SizedBox(height: 15),
              const Center(
                child: Text(
                  'Mode demo. Firebase belum diaktifkan.',
                  style: TextStyle(color: Colors.black45, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;

  final pages = const [
    HomePage(),
    ActivitiesPage(),
    OrganizationPage(),
    FinancePage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) {
          setState(() => selectedIndex = index);
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.event_outlined), label: 'Kegiatan'),
          NavigationDestination(icon: Icon(Icons.account_tree_outlined), label: 'Organisasi'),
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            label: 'Keuangan',
          ),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
        ],
      ),
    );
  }
}

class AppPage extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const AppPage({
    super.key,
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          ...children.map(
            (child) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: child,
            ),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppPage(
      title: 'Karang Taruna Online',
      children: [
        Card(
          child: ListTile(
            title: Text('STATUS ANGGOTA'),
            subtitle: Text('Anggota Aktif'),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.groups),
            title: Text('128'),
            subtitle: Text('Anggota'),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.event),
            title: Text('12'),
            subtitle: Text('Kegiatan bulan ini'),
          ),
        ),
        Text(
          'Agenda Terdekat',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.event),
            title: Text('Gotong Royong Lingkungan'),
            subtitle: Text('17 Agustus, Lapangan Desa'),
          ),
        ),
        Text(
          'Pengumuman Terbaru',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.campaign),
            title: Text('Rapat Pengurus Bulanan'),
            subtitle: Text('Sabtu, 19.30 WIB'),
          ),
        ),
      ],
    );
  }
}

class ActivitiesPage extends StatelessWidget {
  const ActivitiesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppPage(
      title: 'Kegiatan',
      children: [
        Card(
          child: ListTile(
            leading: Icon(Icons.event),
            title: Text('Gotong Royong Lingkungan'),
            subtitle: Text('17 Agustus, Lapangan Desa'),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.event),
            title: Text('Rapat Bulanan'),
            subtitle: Text('24 Agustus, Sekretariat'),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.event),
            title: Text('Turnamen Pemuda'),
            subtitle: Text('31 Agustus, Lapangan Desa'),
          ),
        ),
      ],
    );
  }
}

class OrganizationPage extends StatelessWidget {
  const OrganizationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppPage(
      title: 'Organisasi',
      children: [
        MemberTile(name: 'Budi Santoso', role: 'Ketua'),
        MemberTile(name: 'Andi Pratama', role: 'Wakil Ketua'),
        MemberTile(name: 'Siti Rahma', role: 'Sekretaris'),
        MemberTile(name: 'Dimas Putra', role: 'Bendahara'),
      ],
    );
  }
}

class MemberTile extends StatelessWidget {
  final String name;
  final String role;

  const MemberTile({
    super.key,
    required this.name,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text(name),
        subtitle: Text(role),
      ),
    );
  }
}

class FinancePage extends StatelessWidget {
  const FinancePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppPage(
      title: 'Keuangan',
      children: [
        Card(
          child: ListTile(
            title: Text('SALDO KAS'),
            subtitle: Text(
              'Rp 5.250.000',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.arrow_downward),
            title: Text('Pemasukan'),
            trailing: Text('Rp 2.000.000'),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.arrow_upward),
            title: Text('Pengeluaran'),
            trailing: Text('Rp 750.000'),
          ),
        ),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppPage(
      title: 'Profil',
      children: [
        Center(
          child: CircleAvatar(
            radius: 48,
            child: Icon(Icons.person, size: 50),
          ),
        ),
        SizedBox(height: 8),
        Center(
          child: Text(
            'Anggota Karang Taruna',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.badge_outlined),
            title: Text('Jabatan'),
            subtitle: Text('Anggota'),
          ),
        ),
        Card(
          child: ListTile(
            leading: Icon(Icons.email_outlined),
            title: Text('Email'),
            subtitle: Text('anggota@karangtaruna.id'),
          ),
        ),
      ],
    );
  }
}
