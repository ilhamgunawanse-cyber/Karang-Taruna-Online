# Karang Taruna Online v1.1.2

Build-safe demo version. Firebase is intentionally disabled until the UI build is verified.
