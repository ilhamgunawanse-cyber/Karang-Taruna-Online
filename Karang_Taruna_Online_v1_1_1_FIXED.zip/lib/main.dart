import 'package:flutter/material.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Karang Taruna Online',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B4D)),
      scaffoldBackgroundColor: const Color(0xFFF7F8F6),
    ),
    home: const Splash(),
  );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override State<Splash> createState() => _SplashState();
}
class _SplashState extends State<Splash> {
  @override void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Login()));
    });
  }
  @override Widget build(BuildContext context) => const Scaffold(
    body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.groups_rounded, size: 90, color: Color(0xFF176B4D)),
      SizedBox(height: 20),
      Text('KARANG TARUNA', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
      Text('ONLINE', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: 4)),
      SizedBox(height: 12),
      Text('Satukan Pemuda, Gerakkan Desa.')
    ]));
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override State<Login> createState() => _LoginState();
}
class _LoginState extends State<Login> {
  final e = TextEditingController(), p = TextEditingController();
  void masuk() {
    if (e.text.trim().isEmpty || p.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email dan password wajib diisi.')));
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Shell()));
  }
  @override void dispose() { e.dispose(); p.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 45), const Icon(Icons.groups_rounded, size: 55, color: Color(0xFF176B4D)),
      const SizedBox(height: 24), const Text('Selamat datang', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8), const Text('Masuk ke Karang Taruna Online.'),
      const SizedBox(height: 32),
      TextField(controller: e, decoration: InputDecoration(labelText: 'Email', prefixIcon: const Icon(Icons.email_outlined), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
      const SizedBox(height: 16),
      TextField(controller: p, obscureText: true, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
      const SizedBox(height: 24),
      SizedBox(width: double.infinity, height: 54, child: FilledButton(onPressed: masuk, child: const Text('MASUK'))),
      const SizedBox(height: 15),
      const Center(child: Text('Mode demo. Firebase belum diaktifkan.', style: TextStyle(color: Colors.black45, fontSize: 12)))
    ])));
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int i = 0;
  final pages = const [Home(), Activities(), Organization(), Finance(), Profile()];
  @override Widget build(BuildContext context) => Scaffold(
    body: pages[i],
    bottomNavigationBar: NavigationBar(
      selectedIndex: i,
      onDestinationSelected: (v) => setState(() => i = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.event_outlined), label: 'Kegiatan'),
        NavigationDestination(icon: Icon(Icons.account_tree_outlined), label: 'Organisasi'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Keuangan'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
      ]));
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override Widget build(BuildContext context) => const Page(title: 'Karang Taruna Online', children: [
    Card(child: ListTile(title: Text('STATUS ANGGOTA'), subtitle: Text('Anggota Aktif'))),
    Card(child: ListTile(leading: Icon(Icons.groups), title: Text('128'), subtitle: Text('Anggota'))),
    Card(child: ListTile(leading: Icon(Icons.event), title: Text('12'), subtitle: Text('Kegiatan bulan ini'))),
    Text('Agenda Terdekat', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
    Card(child: ListTile(leading: Icon(Icons.event), title: Text('Gotong Royong Lingkungan'), subtitle: Text('17 Agustus, Lapangan Desa'))),
    Text('Pengumuman Terbaru', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
    Card(child: ListTile(leading: Icon(Icons.campaign), title: Text('Rapat Pengurus Bulanan'), subtitle: Text('Sabtu, 19.30 WIB'))),
  ]);
}

class Activities extends StatelessWidget {
  const Activities({super.key});
  @override Widget build(BuildContext context) => const Page(title: 'Kegiatan', children: [
    Card(child: ListTile(leading: Icon(Icons.event), title: Text('Gotong Royong Lingkungan'), subtitle: Text('17 Agustus, Lapangan Desa'))),
    Card(child: ListTile(leading: Icon(Icons.event), title: Text('Rapat Bulanan'), subtitle: Text('24 Agustus, Sekretariat'))),
    Card(child: ListTile(leading: Icon(Icons.event), title: Text('Turnamen Pemuda'), subtitle: Text('31 Agustus, Lapangan Desa'))),
  ]);
}

class Organization extends StatelessWidget {
  const Organization({super.key});
  @override Widget build(BuildContext context) => const Page(title: 'Organisasi', children: [
    Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Budi Santoso'), subtitle: Text('Ketua'))),
    Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Andi Pratama'), subtitle: Text('Wakil Ketua'))),
    Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Siti Rahma'), subtitle: Text('Sekretaris'))),
    Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Dimas Putra'), subtitle: Text('Bendahara'))),
  ]);
}

class Finance extends StatelessWidget {
  const Finance({super.key});
  @override Widget build(BuildContext context) => const Page(title: 'Keuangan', children: [
    Card(child: ListTile(title: Text('SALDO KAS'), subtitle: Text('Rp 5.250.000', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)))),
    Card(child: ListTile(leading: Icon(Icons.arrow_downward), title: Text('Pemasukan'), trailing: Text('Rp 2.000.000'))),
    Card(child: ListTile(leading: Icon(Icons.arrow_upward), title: Text('Pengeluaran'), trailing: Text('Rp 750.000'))),
  ]);
}

class Profile extends StatelessWidget {
  const Profile({super.key});
  @override Widget build(BuildContext context) => const Page(title: 'Profil', children: [
    Center(child: CircleAvatar(radius: 48, child: Icon(Icons.person, size: 50))),
    Center(child: Text('Anggota Karang Taruna', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
    Card(child: ListTile(leading: Icon(Icons.badge_outlined), title: Text('Jabatan'), subtitle: Text('Anggota'))),
    Card(child: ListTile(leading: Icon(Icons.email_outlined), title: Text('Email'), subtitle: Text('anggota@karangtaruna.id'))),
  ]);
}

class Page extends StatelessWidget {
  final String title; final List<Widget> children;
  const Page({super.key, required this.title, required this.children});
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
    Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
    const SizedBox(height: 20), ...children.map((x) => Padding(padding: const EdgeInsets.only(bottom: 12), child: x))
  ]));
}
