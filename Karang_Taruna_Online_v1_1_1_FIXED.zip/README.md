# Karang Taruna Online v1.1.1 FIXED

Perbaikan untuk splash screen yang berhenti di logo Flutter.

Penyebab versi sebelumnya adalah Firebase diinisialisasi sebelum Firebase dikonfigurasi. Versi ini sementara menggunakan mode demo tanpa Firebase agar APK dapat diuji.

Setelah APK ini lolos QA, Firebase akan ditambahkan kembali dengan konfigurasi yang benar.
