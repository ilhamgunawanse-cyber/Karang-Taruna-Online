# Setup Firebase dari smartphone

1. Buat project Firebase baru dengan nama Karang Taruna Online.
2. Aktifkan Authentication > Email/Password.
3. Buat Firestore Database.
4. Pada environment yang memiliki Flutter + FlutterFire CLI, jalankan:
   flutterfire configure
5. Pilih project Firebase dan Android.
6. File lib/firebase_options.dart akan dibuat otomatis.
7. Jalankan:
   flutter pub get
8. Build:
   flutter build apk --release

Collection Firestore yang digunakan:
- users
- members
- activities
- transactions
- attendance

Contoh document activities:
{
  "title": "Gotong Royong",
  "location": "Lapangan Desa",
  "description": "Gotong royong lingkungan",
  "date": "2026-08-17"
}

Contoh document members:
{
  "name": "Budi Santoso",
  "position": "Ketua"
}

Contoh document transactions:
{
  "type": "income",
  "amount": 1000000,
  "description": "Iuran anggota"
}
