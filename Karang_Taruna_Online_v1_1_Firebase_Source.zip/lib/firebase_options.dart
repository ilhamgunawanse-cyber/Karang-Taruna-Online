// FILE INI HARUS DIGENERATE OLEH FlutterFire CLI.
// Jangan mengisi API key secara manual di source code.
// Jalankan konfigurasi Firebase pada tahap setup Firebase.
// Contoh command:
// flutterfire configure
//
// Setelah command berhasil, file firebase_options.dart akan dibuat otomatis.
// File hasil generate tersebut menggantikan file ini.

import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Firebase belum dikonfigurasi. Jalankan flutterfire configure terlebih dahulu.',
    );
  }
}
